package com.loiane.cursojava.aula44;

public abstract class Mamifero extends Animal {

	public abstract void amamentar();
}
