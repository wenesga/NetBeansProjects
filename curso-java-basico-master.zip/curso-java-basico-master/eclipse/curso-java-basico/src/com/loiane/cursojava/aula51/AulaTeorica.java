package com.loiane.cursojava.aula51;

public class AulaTeorica {
	
	//Nessa aula não temos código fonte, apenas teoria
}
