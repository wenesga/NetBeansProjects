package com.loiane.cursojava.aula11;

public class CuriosidadeInt {

	public static void main(String[] args) {
		
		int var1 = 2147483647;
		
		int var2 = 1;
		
		System.out.println(var1 + var2);	
		
		//-2147483648
		//-2147483648
	}

}
