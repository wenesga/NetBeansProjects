package com.loiane.cursojava.aula44;

public interface AnimalEstimacao {

	void brincar();
	void levarPassear();
}
