package com.loiane.cursojava.aula46;

public class BancoMySQL implements BancoDados {

	@Override
	public void grant(String access) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void remoke(String access) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void select(String query) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void insert(String query) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(String query) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void update(String query) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void create(String query) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void alter(String query) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void drop(String query) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void abrirConexao() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void fecharConexao() {
		// TODO Auto-generated method stub
		
	}

}
