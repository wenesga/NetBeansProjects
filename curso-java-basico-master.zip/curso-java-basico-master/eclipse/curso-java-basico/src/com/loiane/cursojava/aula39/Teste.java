package com.loiane.cursojava.aula39;

public class Teste {

}
