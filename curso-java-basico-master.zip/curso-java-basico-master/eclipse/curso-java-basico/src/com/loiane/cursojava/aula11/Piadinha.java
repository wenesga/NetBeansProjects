package com.loiane.cursojava.aula11;

public class Piadinha {

	public static void main(String[] args) {
		
		int Oct31 = 031;
		
		int Dec25 = 25;
		
		System.out.println(Oct31 == Dec25);

	}

}
