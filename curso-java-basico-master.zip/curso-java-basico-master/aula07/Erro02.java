class Erro02 {
	
	public static void main (String[] args){

		int cont = 0;

		System.out.println("Voce digitou: " + cont);
	}
}