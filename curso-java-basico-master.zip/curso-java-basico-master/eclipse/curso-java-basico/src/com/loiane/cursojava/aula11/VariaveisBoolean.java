package com.loiane.cursojava.aula11;

public class VariaveisBoolean {

	public static void main(String[] args) {
		
		boolean verdadeiro = true;
		
		boolean falso = false;

		System.out.println("O valor de verdadeiro é " + verdadeiro);
		System.out.println("O valor de false é " + falso);
	}

}
